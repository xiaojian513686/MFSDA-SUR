# MFSDASUR 0.1.0

Initial installable package based on the MFSDA-SUR program supplied by Jian Xiao.

## Preserved conventions

- All nine function names and original argument order; the main `$result` matrix.
- Full-sample ordering, centering, row-wise KM weights, and event response basis.
- Gaussian Lasso with `lambda.min`, including glmnet's default standardization
  and intercept; transformed least-squares refits retain an intercept.
- 100 coefficient subsamples by default, each of size `floor(0.632 * split_size)`,
  sampled without replacement. Full-sample weights and response basis are reused.
- Coefficient/SE replacements and the `SE / sqrt(split_size)` statistic scaling.
- Zero selections when at most one candidate is screened.
- Original tail-count threshold without a numerator plus-one; 60% vote threshold.
- Direction search from 1 to `h_value`, scoring all selected matrix entries and
  taking the first maximum, including when multiple target levels are requested.

## Implementation fixes

- Declare and namespace `glmnet`, `splines`, and `stats`; remove unused `ncvreg`.
- Eliminate the undefined `quantile_cutoff` forwarding in the main procedure.
  `quantile_value` controls the main weight computation.
- Replace nested KM products with cumulative products and diagonal weight
  matrices with rowwise multiplication. Floating-point rounding can differ.
- Preserve matrix dimensions; use safe index sequences and direct event matching.
- Return 0/1 screen indicators; accept the original NA-style indicator matrices.
- Remove unused objects and console output from the screening loop.

## Explicit numerical safeguards and added controls

- Validate finite numeric data, binary indicators, index uniqueness, dimensions,
  parameter ranges, positive weights, and spline response variation.
- Require at least 12 total events and feasible split/subsample sizes.
- Insufficient-event splits contribute zero votes, with warnings and diagnostics.
- Cap CV folds for small screening samples; skip constant response/design fits.
- Pad a single-column glmnet design with a discarded zero column; the original
  one-candidate rejection rule is nevertheless preserved in final selection.
- Preserve NA for aliased/non-estimable coefficients and incomplete subsampling
  SDs; report original replacements in main-procedure diagnostics.
- Expose `B`, `subsample_fraction`, `nfolds`, `vote_threshold`, and local `seed`.
- Add per-split statistics, thresholds, selection rates, diagnostics, and all
  candidate fits from the direction-count search.

No empirical FDR validation or new statistical guarantee is asserted by these
software changes. The custom copyright notice is provisional pending the
author's explicit license choice.
