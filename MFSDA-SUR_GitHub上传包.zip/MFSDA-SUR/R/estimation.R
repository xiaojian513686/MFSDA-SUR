.prepare_helper <- function(X, Y, weights, delt, h, sample_index,
                            quantile_cutoff, ratio_censoring) {
    X <- .validate_data(X, Y, delt)
    .validate_weights(weights, delt)
    .scalar_number(h, "h", 1, .Machine$integer.max, integer = TRUE)
    # Retained for compatibility: weights are supplied, not recomputed here.
    .scalar_number(quantile_cutoff, "quantile_cutoff", 0, 1)
    .scalar_number(ratio_censoring, "ratio_censoring", 0, 1)
    list(X = X, basis = fky_split(Y[delt == 1], h)$fky_list,
         sample_index = .sample_indices(sample_index, nrow(X)),
         event_rows = which(delt == 1))
}

.direction_data <- function(X, basis, weights, delt, index, event_rows, k,
                            columns = seq_len(ncol(X))) {
    index <- sort(index)
    events <- which(delt[index] == 1)
    y <- basis[[k]][match(index[events], event_rows)]
    .transform_core(X[index, columns, drop = FALSE], y,
                    weights[index], events)
}

.screen_core <- function(X, basis, weights, delt, index, event_rows, nfolds) {
    p <- ncol(X)
    h <- length(basis)
    selected <- matrix(0L, h, p)
    candidates <- integer()
    event_n <- sum(delt[index] == 1 & weights[index] > 0)
    if (event_n < 9L)
        return(list(index_candidate_0 = candidates, S0 = selected,
                    status = "insufficient_screening_events"))
    # At least three event rows per validation fold where possible.
    folds <- min(nfolds, floor(event_n / 3L))
    for (k in seq_len(h)) {
        obj <- .direction_data(X, basis, weights, delt, index, event_rows, k)
        x <- obj$X_transformation
        y <- obj$Y_transformation
        if (all(y == y[1L]) || !any(vapply(seq_len(p), function(j)
            any(x[, j] != x[1L, j]), logical(1)))) next
        # glmnet requires two columns. The zero column is never a candidate.
        if (p == 1L) x <- cbind(x, .padding = 0)
        cv <- glmnet::cv.glmnet(x, y, family = "gaussian", alpha = 1,
                               nfolds = folds)
        model <- glmnet::glmnet(x, y, family = "gaussian", alpha = 1,
                                lambda = cv$lambda.min)
        beta <- as.numeric(stats::coef(model))[-1L][seq_len(p)]
        which_selected <- which(beta != 0)
        selected[k, which_selected] <- 1L
        candidates <- c(candidates, which_selected)
    }
    list(index_candidate_0 = unique(candidates), S0 = selected, status = "ok")
}

AFT_WLS_lasso <- function(X, Y, weights, delt, h, sample_index,
                          quantile_cutoff = 0.90, ratio_censoring = 0.5,
                          nfolds = 10L) {
    args <- .prepare_helper(X, Y, weights, delt, h, sample_index,
                            quantile_cutoff, ratio_censoring)
    .scalar_number(nfolds, "nfolds", 3, .Machine$integer.max, integer = TRUE)
    ans <- .screen_core(args$X, args$basis, weights, delt, args$sample_index,
                        args$event_rows, nfolds)
    if (ans$status != "ok") warning("Fewer than nine positive-weight events in the screening sample; no candidates returned.",
                                     call. = FALSE)
    ans
}

.wls_direction <- function(obj) {
    p <- ncol(obj$X_transformation)
    n <- nrow(obj$X_transformation)
    if (n < 2L || any(!is.finite(obj$X_transformation)) ||
        any(!is.finite(obj$Y_transformation))) return(rep(NA_real_, p))
    # Preserve the intercept in lm(Y_transformation ~ X_transformation).
    fit <- stats::lm.fit(cbind(1, obj$X_transformation), obj$Y_transformation)
    as.numeric(fit$coefficients[-1L])
}

.wls_core <- function(X, basis, weights, delt, S, index, event_rows) {
    out <- matrix(NA_real_, ncol(X), length(basis))
    if (sum(weights[index]) <= 0 || sum(delt[index] == 1) < 2L) return(out)
    for (k in seq_along(basis)) {
        columns <- which(S[k, ])
        if (!length(columns)) next
        obj <- .direction_data(X, basis, weights, delt, index, event_rows, k, columns)
        out[columns, k] <- .wls_direction(obj)
    }
    out
}

AFT_WLS <- function(X, Y, weights, delt, h, S, sample_index,
                    quantile_cutoff = 0.90, ratio_censoring = 0.5) {
    args <- .prepare_helper(X, Y, weights, delt, h, sample_index,
                            quantile_cutoff, ratio_censoring)
    S <- .selection_matrix(S, h, ncol(args$X))
    ans <- .wls_core(args$X, args$basis, weights, delt, S, args$sample_index,
                     args$event_rows)
    list(model.save_WLS = ans)
}

.se_core <- function(X, basis, weights, delt, S, index, event_rows, B,
                      subsample_fraction) {
    p <- ncol(X)
    h <- length(basis)
    out <- matrix(NA_real_, p, h)
    counts <- matrix(0L, p, h)
    size <- floor(subsample_fraction * length(index))
    for (k in seq_len(h)) {
        columns <- which(S[k, ])
        if (!length(columns)) {
            out[, k] <- 0
            next
        }
        draws <- matrix(NA_real_, B, length(columns))
        for (b in seq_len(B)) {
            sub <- sort(index[sample.int(length(index), size, replace = FALSE)])
            if (sum(weights[sub]) <= 0 || sum(delt[sub] == 1) < 2L) next
            obj <- .direction_data(X, basis, weights, delt, sub, event_rows, k, columns)
            draws[b, ] <- .wls_direction(obj)
        }
        # No na.rm: a non-estimable resample leaves an NA, as in the source.
        out[columns, k] <- vapply(seq_along(columns), function(j)
            stats::sd(draws[, j]), numeric(1))
        counts[columns, k] <- colSums(is.finite(draws))
    }
    list(se_matrix = out, valid_replicates = counts)
}

AFT_WLS_se <- function(X, Y, weights, delt, h, S, quantile_cutoff = 0.90,
                       ratio_censoring = 0.5, sample_index, B = 100L,
                       subsample_fraction = 0.632, seed = NULL) {
    args <- .prepare_helper(X, Y, weights, delt, h, sample_index,
                            quantile_cutoff, ratio_censoring)
    S <- .selection_matrix(S, h, ncol(args$X))
    .scalar_number(B, "B", 2, .Machine$integer.max, integer = TRUE)
    .scalar_number(subsample_fraction, "subsample_fraction", 0, 1, open = TRUE)
    if (floor(subsample_fraction * length(args$sample_index)) < 2L)
        stop("The subsample must contain at least two observations.", call. = FALSE)
    .with_seed(seed, .se_core(args$X, args$basis, weights, delt, S,
        args$sample_index, args$event_rows, B, subsample_fraction))
}
