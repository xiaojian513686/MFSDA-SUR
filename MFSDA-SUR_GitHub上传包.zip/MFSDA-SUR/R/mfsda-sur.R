.mirror_threshold <- function(statistic, q) {
    cutoff <- sort(unique(abs(statistic)))
    for (t in cutoff) {
        ratio <- sum(statistic <= -t) / max(sum(statistic >= t), 1L)
        if (ratio <= q) return(t)
    }
    Inf
}

MFSDA_SUR <- function(X, Y, delt, quantile_value = 0.90,
                      ratio_censoring = 0.5, h = 5L, ratio_SDA = 2/3,
                      fdrlevel = 0.1, DS = 5L, B = 100L,
                      subsample_fraction = 0.632, nfolds = 10L,
                      vote_threshold = 0.6, seed = NULL) {
    call <- match.call()
    X <- .validate_data(X, Y, delt)
    .scalar_number(quantile_value, "quantile_value", 0, 1)
    .scalar_number(ratio_censoring, "ratio_censoring", 0, 1)
    .scalar_number(h, "h", 1, .Machine$integer.max, integer = TRUE)
    .scalar_number(ratio_SDA, "ratio_SDA", 0, 1, open = TRUE)
    .scalar_number(DS, "DS", 1, .Machine$integer.max, integer = TRUE)
    .scalar_number(B, "B", 2, .Machine$integer.max, integer = TRUE)
    .scalar_number(subsample_fraction, "subsample_fraction", 0, 1, open = TRUE)
    .scalar_number(nfolds, "nfolds", 3, .Machine$integer.max, integer = TRUE)
    .scalar_number(vote_threshold, "vote_threshold", 0, 1)
    if (vote_threshold == 0) stop("vote_threshold must be greater than zero.", call. = FALSE)
    .numeric_vector(fdrlevel, "fdrlevel")
    if (any(fdrlevel <= 0 | fdrlevel >= 1))
        stop("Each fdrlevel must lie strictly between zero and one.", call. = FALSE)
    n <- nrow(X)
    p <- ncol(X)
    n1 <- round(ratio_SDA * n)
    if (n1 < 9L || n - n1 < 3L)
        stop("The split must contain at least nine screening rows and three refit rows; increase n or change ratio_SDA.",
             call. = FALSE)
    if (floor(subsample_fraction * min(n1, n - n1)) < 2L)
        stop("Each subsample must contain at least two rows; increase sample size or subsample_fraction.",
             call. = FALSE)
    if (sum(delt == 1) < 12L)
        stop("At least 12 observed events are required for screening and refitting.", call. = FALSE)

    ordered <- order(Y)
    Y <- Y[ordered]
    delt <- delt[ordered]
    weights <- n * km_weights_function(delt, quantile_value, ratio_censoring)$weights
    .validate_weights(weights, delt)
    X <- scale(X[ordered, , drop = FALSE], center = TRUE, scale = FALSE)
    basis <- fky_split(Y[delt == 1], h)$fky_list
    event_rows <- which(delt == 1)
    variable_names <- colnames(X)
    if (is.null(variable_names)) variable_names <- paste0("X", seq_len(p))
    q_names <- as.character(fdrlevel)

    .with_seed(seed, {
        selections <- array(0L, c(p, DS, length(fdrlevel)),
                            dimnames = list(variable_names, paste0("split", seq_len(DS)), q_names))
        statistics <- matrix(NA_real_, p, DS, dimnames = dimnames(selections)[1:2])
        thresholds <- matrix(Inf, DS, length(fdrlevel),
                             dimnames = dimnames(selections)[2:3])
        diagnostics <- data.frame(
            split = seq_len(DS), status = rep("pending", DS),
            screening_events = integer(DS), refit_events = integer(DS),
            candidates = integer(DS), invalid_coefficients = integer(DS),
            replaced_se = integer(DS), incomplete_se = integer(DS),
            stringsAsFactors = FALSE)

        for (ii in seq_len(DS)) {
            perm <- sample.int(n)
            first <- perm[seq_len(n1)]
            second <- perm[seq.int(n1 + 1L, n)]
            diagnostics$screening_events[ii] <- sum(delt[first] == 1 & weights[first] > 0)
            diagnostics$refit_events[ii] <- sum(delt[second] == 1 & weights[second] > 0)
            if (diagnostics$screening_events[ii] < 9L || diagnostics$refit_events[ii] < 3L) {
                diagnostics$status[ii] <- "insufficient_events"
                next
            }
            screen <- .screen_core(X, basis, weights, delt, first, event_rows, nfolds)
            diagnostics$candidates[ii] <- length(screen$index_candidate_0)
            if (length(screen$index_candidate_0) <= 1L) {
                diagnostics$status[ii] <- "at_most_one_candidate"
                next
            }
            S <- screen$S0 != 0
            b1 <- .wls_core(X, basis, weights, delt, S, first, event_rows)
            s1 <- .se_core(X, basis, weights, delt, S, first, event_rows, B, subsample_fraction)
            b2 <- .wls_core(X, basis, weights, delt, S, second, event_rows)
            s2 <- .se_core(X, basis, weights, delt, S, second, event_rows, B, subsample_fraction)
            active <- t(S)
            diagnostics$invalid_coefficients[ii] <- sum(!is.finite(b1[active])) +
                sum(!is.finite(b2[active]))
            diagnostics$incomplete_se[ii] <- sum(s1$valid_replicates[active] < B) +
                sum(s2$valid_replicates[active] < B)
            e1 <- s1$se_matrix
            e2 <- s2$se_matrix
            diagnostics$replaced_se[ii] <- sum(!is.finite(e1[active]) | e1[active] == 0) +
                sum(!is.finite(e2[active]) | e2[active] == 0)
            b1[!is.finite(b1)] <- 0
            b2[!is.finite(b2)] <- 0
            e1[!is.finite(e1) | e1 == 0] <- 1
            e2[!is.finite(e2) | e2 == 0] <- 1
            statistic <- rowSums((b1 / (e1 / sqrt(n1))) * (b2 / (e2 / sqrt(n - n1))))
            if (any(!is.finite(statistic)))
                stop("Non-finite selection statistics; inspect covariate scales and refits.", call. = FALSE)
            statistics[, ii] <- statistic
            diagnostics$status[ii] <- "ok"
            for (l in seq_along(fdrlevel)) {
                threshold <- .mirror_threshold(statistic, fdrlevel[l])
                thresholds[ii, l] <- threshold
                selections[, ii, l] <- as.integer(statistic >= threshold)
            }
        }
        rates <- matrix(0, p, length(fdrlevel), dimnames = list(variable_names, q_names))
        for (l in seq_along(fdrlevel))
            rates[, l] <- rowMeans(matrix(selections[, , l], p, DS))
        result <- matrix(as.integer(rates >= vote_threshold), p, length(fdrlevel),
                         dimnames = dimnames(rates))
        if (any(diagnostics$status == "insufficient_events"))
            warning(sum(diagnostics$status == "insufficient_events"),
                    " split(s) had insufficient events and contributed zero votes; inspect diagnostics.",
                    call. = FALSE)
        if (any(diagnostics$invalid_coefficients > 0 | diagnostics$replaced_se > 0))
            warning("Some selected directions used the original coefficient/SE fallback; inspect diagnostics before interpreting results.",
                    call. = FALSE)
        structure(list(result = result, selection_rate = rates,
            split_selection = selections, statistics = statistics,
            thresholds = thresholds, diagnostics = diagnostics,
            parameters = list(h = h, DS = DS, B = B, fdrlevel = fdrlevel,
                ratio_SDA = ratio_SDA, quantile_value = quantile_value,
                ratio_censoring = ratio_censoring, subsample_fraction = subsample_fraction,
                nfolds = nfolds, vote_threshold = vote_threshold, seed = seed),
            call = call), class = "mfsda_sur")
    })
}

MFSDA_SUR_combine <- function(X, Y, delt, quantile_value = 0.90,
                              ratio_censoring = 0.5, h_value = 5L,
                              ratio_SDA = 2/3, fdrlevel = 0.1, DS = 5L,
                              B = 100L, subsample_fraction = 0.632,
                              nfolds = 10L, vote_threshold = 0.6, seed = NULL) {
    call <- match.call()
    .scalar_number(h_value, "h_value", 1, .Machine$integer.max, integer = TRUE)
    .with_seed(seed, {
        fits <- lapply(seq_len(h_value), function(k)
            MFSDA_SUR(X = X, Y = Y, delt = delt,
                quantile_value = quantile_value, ratio_censoring = ratio_censoring,
                h = k, ratio_SDA = ratio_SDA, fdrlevel = fdrlevel, DS = DS,
                B = B, subsample_fraction = subsample_fraction,
                nfolds = nfolds, vote_threshold = vote_threshold))
        counts <- vapply(fits, function(fit) sum(fit$result), numeric(1))
        best <- which.max(counts)
        names(fits) <- names(counts) <- as.character(seq_len(h_value))
        structure(list(result = fits[[best]]$result, h_opt = best,
            selection_counts = counts, fits = fits, call = call),
            class = "mfsda_sur_combine")
    })
}

print.mfsda_sur <- function(x, ...) {
    cat("MFSDA-SUR variable selection\n")
    cat("Directions:", x$parameters$h, " | Splits:", x$parameters$DS,
        " | Subsamples per direction:", x$parameters$B, "\n")
    counts <- data.frame(fdrlevel = colnames(x$result),
                         selected = colSums(x$result), row.names = NULL)
    print(counts, row.names = FALSE)
    cat("Completed selection statistics:", sum(x$diagnostics$status == "ok"),
        "of", nrow(x$diagnostics), "splits; see $diagnostics.\n")
    invisible(x)
}

print.mfsda_sur_combine <- function(x, ...) {
    cat("MFSDA-SUR direction-count search\n")
    cat("Chosen h:", x$h_opt, "(largest total selection count; first tie)\n")
    print(data.frame(h = as.integer(names(x$selection_counts)),
                     selection_count = as.numeric(x$selection_counts)), row.names = FALSE)
    invisible(x)
}
