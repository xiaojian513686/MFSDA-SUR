.scalar_number <- function(x, name, lower = -Inf, upper = Inf,
                           integer = FALSE, open = FALSE) {
    valid <- is.numeric(x) && length(x) == 1L && !is.na(x) && is.finite(x)
    if (valid) {
        valid <- if (open) x > lower && x < upper else x >= lower && x <= upper
        if (integer) valid <- valid && x == floor(x)
    }
    if (!valid) stop(name, " must be a finite ",
        if (integer) "integer" else "number", " in ",
        if (open) "(" else "[", lower, ", ", upper,
        if (open) ")" else "]", ".", call. = FALSE)
    invisible(x)
}

.numeric_vector <- function(x, name, n = NULL) {
    if (!is.numeric(x) || !is.null(dim(x)) || !length(x) ||
        anyNA(x) || any(!is.finite(x)))
        stop(name, " must be a nonempty finite numeric vector.", call. = FALSE)
    if (!is.null(n) && length(x) != n)
        stop(name, " must have length ", n, ".", call. = FALSE)
    invisible(x)
}

.event_vector <- function(delt, n = NULL) {
    if ((!is.numeric(delt) && !is.logical(delt)) || !is.null(dim(delt)) ||
        !length(delt) || anyNA(delt) || any(!delt %in% c(0, 1)))
        stop("delt must be a nonempty vector of 0 (censored) and 1 (event).",
             call. = FALSE)
    if (!is.null(n) && length(delt) != n)
        stop("delt must have one entry per row of X.", call. = FALSE)
    invisible(delt)
}

.design_matrix <- function(X) {
    if (is.data.frame(X)) {
        if (!all(vapply(X, is.numeric, logical(1))))
            stop("All columns of X must be numeric.", call. = FALSE)
        X <- as.matrix(X)
    } else if (is.numeric(X) && is.null(dim(X))) {
        X <- matrix(X, ncol = 1L)
    }
    if (!is.matrix(X) || !is.numeric(X) || !nrow(X) || !ncol(X) ||
        anyNA(X) || any(!is.finite(X)))
        stop("X must be a nonempty finite numeric matrix or numeric data frame.",
             call. = FALSE)
    storage.mode(X) <- "double"
    X
}

.validate_data <- function(X, Y, delt) {
    X <- .design_matrix(X)
    .numeric_vector(Y, "Y", nrow(X))
    .event_vector(delt, nrow(X))
    if (!any(delt == 1)) stop("At least one observed event is required.", call. = FALSE)
    X
}

.validate_weights <- function(weights, delt) {
    .numeric_vector(weights, "weights", length(delt))
    if (any(weights < 0) || any(weights[delt == 0] != 0))
        stop("weights must be nonnegative and zero for censored observations.",
             call. = FALSE)
    if (sum(weights) <= 0 || !is.finite(sum(weights)))
        stop("weights must have a positive finite sum; check the weight cutoff.",
             call. = FALSE)
    invisible(weights)
}

.sample_indices <- function(sample_index, n) {
    .numeric_vector(sample_index, "sample_index")
    if (any(sample_index != floor(sample_index)) ||
        any(sample_index < 1 | sample_index > n) || anyDuplicated(sample_index))
        stop("sample_index must contain distinct row indices between 1 and nrow(X).",
             call. = FALSE)
    sort(as.integer(sample_index))
}

.selection_matrix <- function(S, h, p) {
    if (!is.matrix(S) || (!is.numeric(S) && !is.logical(S)) ||
        !identical(dim(S), as.integer(c(h, p))) ||
        any(!is.na(S) & !is.finite(S)))
        stop("S must be an h by ncol(X) numeric or logical matrix.", call. = FALSE)
    S[is.na(S)] <- 0
    S != 0
}

.with_seed <- function(seed, code) {
    if (is.null(seed)) return(force(code))
    .scalar_number(seed, "seed", 0, .Machine$integer.max, integer = TRUE)
    existed <- exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    if (existed) previous <- get(".Random.seed", envir = .GlobalEnv, inherits = FALSE)
    on.exit({
        if (existed) assign(".Random.seed", previous, envir = .GlobalEnv)
        else if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
            rm(".Random.seed", envir = .GlobalEnv)
    }, add = TRUE)
    set.seed(seed)
    force(code)
}
