# The input order is the time order. This intentionally retains the supplied
# row-wise tie convention, rather than replacing it with a grouped KM estimator.
km_weights_function <- function(delt, quantile_cutoff = 0.95,
                                ratio_censoring = 0.5) {
    .event_vector(delt)
    .scalar_number(quantile_cutoff, "quantile_cutoff", 0, 1)
    .scalar_number(ratio_censoring, "ratio_censoring", 0, 1)
    n <- length(delt)
    at_risk <- rev(seq_len(n))
    survival_after <- cumprod(1 - delt / at_risk)
    survival_before <- c(1, survival_after[seq_len(n - 1L)])
    weights <- survival_before * delt / at_risk
    if (1 - mean(delt) > ratio_censoring) {
        cap <- as.numeric(stats::quantile(weights, quantile_cutoff, names = FALSE))
        weights <- pmin(weights, cap)
    }
    list(weights = weights)
}

km_transformation_function <- function(X, Y, weights_vector, delt) {
    X <- .design_matrix(X)
    .event_vector(delt, nrow(X))
    .validate_weights(weights_vector, delt)
    index <- which(delt == 1)
    .numeric_vector(Y, "Y", length(index))
    .transform_core(X, Y, weights_vector, index)
}

.transform_core <- function(X, Y, weights, event_index) {
    total <- sum(weights)
    x_mean <- colSums(X * weights) / total
    w <- weights[event_index]
    y_mean <- sum(w * Y) / sum(w)
    list(
        X_transformation = sweep(X[event_index, , drop = FALSE], 2L, x_mean) * sqrt(w),
        Y_transformation = sqrt(w) * (Y - y_mean),
        X_transformation_mean = x_mean,
        Y_transformation_mean = y_mean
    )
}

data_seq <- function(x, h) {
    .numeric_vector(x, "x")
    .scalar_number(h, "h", 1, .Machine$integer.max, integer = TRUE)
    as.numeric(stats::quantile(x, probs = seq(0, 1, length.out = h + 1L)))
}

fky_split <- function(Y, h) {
    .numeric_vector(Y, "Y")
    .scalar_number(h, "h", 1, .Machine$integer.max, integer = TRUE)
    if (h == 1L) return(list(fky_list = list(Y)))
    if (length(unique(Y)) < 2L)
        stop("At least two distinct event outcomes are required when h >= 2.",
             call. = FALSE)
    basis <- splines::bs(Y, df = h, degree = 2)
    if (ncol(basis) != h || any(!is.finite(basis)))
        stop("The spline response basis is not finite; reduce h or inspect Y.",
             call. = FALSE)
    list(fky_list = lapply(seq_len(h), function(k) as.numeric(basis[, k])))
}
