# MFSDA-SUR R 软件包使用说明

版本：0.1.0  
作者及维护者：Jian Xiao  
邮箱：xiaoj771@sina.com

## 1. 名称和文件

项目名称为 **MFSDA-SUR**。由于 R 软件包名称不允许包含连字符，
`DESCRIPTION` 中的包名及加载名称使用 **MFSDASUR**。
主函数名称保持为 `MFSDA_SUR()` 和 `MFSDA_SUR_combine()`。

`MFSDASUR_0.1.0.tar.gz` 是可安装的 R 源码包。
`MFSDA-SUR_source_0.1.0.zip` 是便于查看、编辑的完整项目源码。
不要把项目源码 ZIP 当成 Windows 二进制 R 包安装；请使用 `.tar.gz`。

## 2. 安装

上传完成后，可从指定仓库的子目录安装：

```r
install.packages("remotes", repos = "https://cloud.r-project.org")
remotes::install_github("xiaojian513686/xiaojian_zuel",
                        subdir = "MFSDA-SUR")
library(MFSDASUR)
```

也可下载 `dist/MFSDASUR_0.1.0.tar.gz`，按下述方式本地安装。

需要 R 4.1.0 或更高版本。先安装实际使用的外部依赖 `glmnet`：

```r
install.packages("glmnet", repos = "https://cloud.r-project.org")
```

把下载的 `.tar.gz` 文件放到当前工作目录，再运行：

```r
install.packages("MFSDASUR_0.1.0.tar.gz", repos = NULL, type = "source")
library(MFSDASUR)
```

也可以交互选择下载文件：

```r
install.packages(file.choose(), repos = NULL, type = "source")
```

本包本身不包含需要编译的 C/C++/Fortran 代码。`glmnet` 及其依赖
可以优先安装适配当前 R 版本的二进制包；若从源码安装依赖，
可能需要相应的编译工具。`stats` 和 `splines` 随 R 提供。
原程序未实际使用 `ncvreg`，因此本包不依赖它。
本次交付不代表已上传 CRAN。

## 3. 输入数据

| 参数 | 含义 |
| --- | --- |
| `X` | n 行、p 列的数值型协变量矩阵；也接受全部列均为数值的 data.frame |
| `Y` | 长度为 n 的观测结局，包括删失观测对应的结局值 |
| `delt` | 长度为 n；1 表示事件已观察到，0 表示右删失 |

如果使用原始生存时间，通常先构造 `Y <- pmin(T, C)` 和
`delt <- as.integer(T <= C)`。如果研究设计使用对数时间，则在调用前
自行变换，且原始时间必须为正。**函数不会自动对 `Y` 取对数。**
下方示例直接生成对数时间，所以 `Y` 可以为负。

数据中不能含 `NA`、`NaN` 或 `Inf`。分类变量需事先按研究设计编码，
函数不会自动插补或把因子强制变为数值。主函数会按 `Y` 排序并居中 `X`。

## 4. 可复现示例

```r
library(MFSDASUR)
set.seed(2026)
n <- 300
p <- 8
X <- matrix(rnorm(n * p), n, p)
colnames(X) <- paste0("x", seq_len(p))

log_time <- 1.5 * X[, 1] - X[, 2] + 0.8 * X[, 3] + rnorm(n)
log_censor <- rnorm(n, mean = 3, sd = 2)
Y <- pmin(log_time, log_censor)
delt <- as.integer(log_time <= log_censor)

fit <- MFSDA_SUR(
  X, Y, delt,
  h = 3,
  fdrlevel = c(0.1, 0.2),
  DS = 5,
  B = 100,
  seed = 2026
)

print(fit)
fit$result
fit$selection_rate
fit$diagnostics

# 提取目标水平为 0.1 时入选的变量名
selected <- rownames(fit$result)[fit$result[, "0.1"] == 1]
selected
```

此例用于展示调用方法，不是经验 FDR 仿真验证。
`seed` 参数控制函数内部随机性，并在结束时恢复调用前的随机状态。
不传 `seed` 时，沿用并推进 R 当前随机状态，可在函数外调用 `set.seed()`。

## 5. 主要参数

| 参数 | 默认值 | 说明 |
| --- | --- | --- |
| `quantile_value` | 0.90 | 主函数的权重截尾分位数 |
| `ratio_censoring` | 0.5 | 删失比例严格超过此值时才截尾 |
| `h` | 5 | 响应方向数；1 时使用原响应，2 及以上使用二次 B 样条 |
| `ratio_SDA` | 2/3 | 第一部分样本占比，样本量按 `round()` 取整 |
| `fdrlevel` | 0.1 | 一个或多个介于 0 和 1 之间的目标水平 |
| `DS` | 5 | 重复样本分割次数 |
| `B` | 100 | 每部分样本、每方向的重抽样次数 |
| `subsample_fraction` | 0.632 | 无放回子样本占比，样本量向下取整 |
| `nfolds` | 10 | Lasso 请求折数；事件少时自动减少，以每折至少约 3 个事件为限 |
| `vote_threshold` | 0.6 | 最终入选所需投票比例，使用大于等于门槛的规则 |
| `seed` | NULL | 可选随机种子 |

正式分析可保留原始的 `B = 100`、`DS = 5`。
帮助页面使用较小 `B`、`DS`，仅为缩短示例运行时间。

## 6. 结果对象

`fit$result` 保留原程序的接口：p 行、目标水平数列的 0/1 矩阵。
1 表示入选，0 表示未入选；列名是目标水平，行名来自 `colnames(X)`，
未提供名称时自动使用 `X1`、`X2` 等。

其他字段：

- `selection_rate`：各变量在全部 `DS` 次分割中的入选比例。
- `split_selection`：变量 × 分割 × 水平的 0/1 数组。
- `statistics`：变量 × 分割的统计量矩阵；跳过的分割记为 `NA`。
- `thresholds`：每次分割、每个水平的阈值；没有可用阈值时为 `Inf`。
- `diagnostics`：每次分割的事件数、候选数及退化估计诊断。
- `parameters`、`call`：运行参数与调用记录。

`diagnostics$status` 的含义：

| 状态 | 含义 |
| --- | --- |
| `ok` | 已完成统计量及阈值计算；仍需检查替代值计数 |
| `at_most_one_candidate` | 候选变量不超过 1 个，按原程序规则贡献零票 |
| `insufficient_events` | 第一部分少于 9 个或第二部分少于 3 个正权重事件，贡献零票并警告 |

`invalid_coefficients` 记录已筛中方向里被替换为 0 的系数数量；
`replaced_se` 记录被替换为 1 的标准误数量；
`incomplete_se` 记录未获得全部 `B` 个有效重抽样系数的标准误数量。
这些数量对两个样本部分求和，不包含正常未筛中的方向。
出现这些计数时，应检查删失比例、共线性、筛选规模及样本量。
跳过的分割仍计入投票分母 `DS`，不会悄悄提高其他分割的权重。

## 7. 方向数选择

```r
combined <- MFSDA_SUR_combine(
  X, Y, delt,
  h_value = 5,
  fdrlevel = 0.1,
  DS = 5,
  B = 100,
  seed = 2026
)

combined$h_opt
combined$selection_counts
combined$result
combined$fits[[combined$h_opt]]$diagnostics
```

函数依次计算 `h = 1, ..., h_value`，选择最终入选矩阵中 1 的数量最多的
`h`；并列时取最小 `h`，全部为 0 时取 1。
若传入多个 `fdrlevel`，计数会跨全部列累加，同一变量可能被多次计数。
不同 `h` 沿随机数流分别分割，不强制使用同一组划分。
这是原程序的选择数量规则，不是预测交叉验证，也不证明所选 `h` 在统计意义上最优。

## 8. 保留的统计规则与代码修复

保留的规则包括：全样本 KM 权重和样条基；`glmnet` 的 `lambda.min`；
变换后带截距的最小二乘；0.632 无放回子样本；标准误的原缩放方式；
负尾计数/正尾计数阈值（分子不加 1）；候选数不超过 1 时不选变量；
60% 投票；按入选数量选择方向数。

修复与增强包括：

- 显式使用 `glmnet::cv.glmnet()`、`glmnet::glmnet()`，避免依赖手动加载包。
- 去除主函数中未定义 `quantile_cutoff` 的转发引用；权重由 `quantile_value` 控制。
- KM 权重改为累计乘积，避免双重循环；加权变换避免构造 n × n 对角矩阵。
- 使用 `drop = FALSE` 保留单列、单事件时的矩阵维度。
- 用 0/1 筛选矩阵替代以 `NA` 表示未筛中的矩阵；兼容输入的旧式 `NA` 筛选矩阵。
- 处理空候选、常数方向、全零权重、少事件和无法估计的重抽样系数。
- 单列 Lasso 添加随后丢弃的全零列，以满足 `glmnet` 的输入要求。
- 删除中间 `cat()` 输出，增加可追踪的诊断和可选局部随机种子。

新增的最小事件数和小样本折数限制属于数值保护；这些边界情况下
不会声称与可能报错的原脚本逐步完全一致。浮点运算顺序改变也可能影响
恰好位于阈值附近的结果。回归测试核对的是文档所述测试数据上的一致性。

原程序的几个方法约定没有被擅自改写：同一观测时间内按输入行顺序处理，
所以事件与删失的并列顺序可能影响 KM 权重；权重截尾分位数包含删失行的零权重；
重抽样不重新估计 KM 权重和样条基；标准误替代规则保留。
即使输入只含一个协变量，原先“候选数不超过 1 时不选”的规则依然适用。

本包没有新增通用 FDR 保证，也没有把自适应方向数选择和重复投票解释成已有的
FDR 理论证明。软件测试与大规模经验 FDR 仿真是不同的验证工作。

## 9. 底层函数与帮助

原来的 9 个函数均已导出：

`km_weights_function`、`km_transformation_function`、`data_seq`、`fky_split`、
`AFT_WLS_lasso`、`AFT_WLS`、`AFT_WLS_se`、`MFSDA_SUR`、`MFSDA_SUR_combine`。

注意：仅 `km_transformation_function()` 的 `Y` 要传入事件行响应，
长度应为 `sum(delt == 1)`；主函数和三个 `AFT_WLS*` 函数的 `Y` 都是全样本向量。
三个 `AFT_WLS*` 函数接受已经计算并对齐的权重，不会按其兼容参数重新截尾。

```r
help(package = "MFSDASUR")
?MFSDA_SUR
?MFSDA_SUR_combine
?AFT_WLS_se
source(system.file("examples", "quick_start.R", package = "MFSDASUR"))
```

开发者可在 GitHub 仓库根目录运行：

```sh
R CMD build MFSDA-SUR
R CMD check --no-manual MFSDASUR_0.1.0.tar.gz
```

## 10. 版权

Copyright (c) 2026 Jian Xiao。尚未指定开源许可证；当前开发版保留版权，
具体使用、修改与再分发授权请联系作者。此声明没有替作者选择 MIT 或 GPL。
