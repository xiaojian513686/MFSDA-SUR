# MFSDA-SUR / MFSDASUR 0.1.0
# Author: Jian Xiao <xiaoj771@sina.com>
# Install glmnet and MFSDASUR before running this example.
library(MFSDASUR)

set.seed(2026)
n <- 300
p <- 8
X <- matrix(rnorm(n * p), nrow = n, ncol = p)
colnames(X) <- paste0("x", seq_len(p))
log_time <- 1.5 * X[, 1] - X[, 2] + 0.8 * X[, 3] + rnorm(n)
log_censor <- rnorm(n, mean = 3, sd = 2)
Y <- pmin(log_time, log_censor)
delt <- as.integer(log_time <= log_censor)

fit <- MFSDA_SUR(X, Y, delt, h = 3, fdrlevel = c(0.1, 0.2),
                 DS = 5, B = 100, seed = 2026)
print(fit)
print(fit$result)
print(fit$diagnostics)
selected <- rownames(fit$result)[fit$result[, "0.1"] == 1]
print(selected)

# The original selection-count heuristic, using default DS and B.
combined <- MFSDA_SUR_combine(X, Y, delt, h_value = 3, seed = 2026)
print(combined)
print(combined$result)
