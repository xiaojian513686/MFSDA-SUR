# Independent, deliberately direct transcription of the supplied algorithm.
# Restricted to well-conditioned fixtures. Dimensions are held explicitly and
# the undefined quantile_cutoff forwarding is replaced by quantile_value.
reference_weights <- function(delt, cutoff = 0.95, ratio = 0.5) {
    n <- length(delt)
    w <- numeric(n)
    for (i in seq_len(n)) {
        survival <- 1
        for (j in seq_len(i - 1L))
            survival <- survival * ((n - j) / (n - j + 1))^delt[j]
        w[i] <- survival * delt[i] / (n - i + 1)
    }
    if (1 - mean(delt) > ratio) w[w > stats::quantile(w, cutoff)] <- stats::quantile(w, cutoff)
    w
}

reference_transform <- function(X, Y, w, delt) {
    event <- which(delt == 1)
    W <- diag(w, nrow = length(w))
    y_mean <- sum(W[event, event, drop = FALSE] %*% Y) / sum(w[event])
    x_mean <- colSums(W %*% X) / sum(w)
    xx <- matrix(0, nrow(X), ncol(X))
    for (i in seq_len(nrow(X))) xx[i, ] <- sqrt(W[i, i]) * (X[i, ] - x_mean)
    list(x = xx[event, , drop = FALSE], y = sqrt(w[event]) * (Y - y_mean))
}

reference_select <- function(X, Y, delt, h, DS, B, q) {
    n <- nrow(X)
    p <- ncol(X)
    ord <- order(Y)
    Y <- Y[ord]
    delt <- delt[ord]
    X <- scale(X[ord, , drop = FALSE], center = TRUE, scale = FALSE)
    w <- n * reference_weights(delt, 0.90, 0.5)
    response <- if (h == 1L) matrix(Y[delt == 1], ncol = 1L) else
        splines::bs(Y[delt == 1], df = h, degree = 2)
    events <- which(delt == 1)
    direction <- function(index, cols, k) {
        index <- sort(index)
        response_rows <- match(index[delt[index] == 1], events)
        reference_transform(X[index, cols, drop = FALSE], response[response_rows, k],
                            w[index], delt[index])
    }
    screen <- function(index) {
        S <- matrix(FALSE, h, p)
        for (k in seq_len(h)) {
            obj <- direction(index, seq_len(p), k)
            cv <- glmnet::cv.glmnet(obj$x, obj$y, family = "gaussian", alpha = 1)
            mod <- glmnet::glmnet(obj$x, obj$y, family = "gaussian", alpha = 1,
                                  lambda = cv$lambda.min)
            S[k, ] <- as.numeric(stats::coef(mod))[-1L] != 0
        }
        S
    }
    refit <- function(index, S) {
        ans <- matrix(NA_real_, p, h)
        for (k in seq_len(h)) {
            cols <- which(S[k, ])
            if (!length(cols)) next
            obj <- direction(index, cols, k)
            ans[cols, k] <- stats::coef(stats::lm(obj$y ~ obj$x))[-1L]
        }
        ans
    }
    variability <- function(index, S) {
        ans <- matrix(NA_real_, p, h)
        for (k in seq_len(h)) {
            cols <- which(S[k, ])
            draws <- matrix(NA_real_, B, p)
            for (b in seq_len(B)) {
                if (length(cols)) {
                    take <- sample(seq_along(index), floor(0.632 * length(index)), replace = FALSE)
                    obj <- direction(index[take], cols, k)
                    draws[b, cols] <- stats::coef(stats::lm(obj$y ~ obj$x))[-1L]
                } else draws[b, ] <- 0
            }
            for (j in seq_len(p)) ans[j, k] <- stats::sd(draws[, j])
        }
        ans
    }
    votes <- array(0L, c(p, DS, length(q)))
    statistics <- matrix(NA_real_, p, DS)
    for (s in seq_len(DS)) {
        n1 <- round(2/3 * n)
        perm <- sample(seq_len(n))
        first <- perm[seq_len(n1)]
        second <- perm[seq.int(n1 + 1L, n)]
        S <- screen(first)
        if (sum(colSums(S) > 0) <= 1L) next
        b1 <- refit(first, S)
        e1 <- variability(first, S)
        b2 <- refit(second, S)
        e2 <- variability(second, S)
        b1[is.na(b1)] <- b2[is.na(b2)] <- 0
        e1[is.na(e1) | e1 == 0] <- 1
        e2[is.na(e2) | e2 == 0] <- 1
        ts <- numeric(p)
        for (j in seq_len(p))
            ts[j] <- sum((b1[j, ] / (e1[j, ] / sqrt(n1))) *
                         (b2[j, ] / (e2[j, ] / sqrt(n - n1))))
        statistics[, s] <- ts
        for (l in seq_along(q)) {
            t <- NA_real_
            for (candidate in sort(abs(ts))) {
                if (sum(ts <= -candidate) / max(sum(ts >= candidate), 1) <= q[l]) {
                    t <- candidate
                    break
                }
            }
            votes[which(ts >= t), s, l] <- 1L
        }
    }
    rates <- matrix(0, p, length(q))
    for (l in seq_along(q)) for (j in seq_len(p)) rates[j, l] <- mean(votes[j, , l])
    list(result = 1L * (rates >= 0.6), rates = rates, statistics = statistics, votes = votes)
}
