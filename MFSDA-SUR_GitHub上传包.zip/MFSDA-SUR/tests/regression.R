library(MFSDASUR)
source(file.path("helpers", "reference.R"))

checks <- 0L
check <- function(ok) {
    if (!isTRUE(ok)) stop("Assertion ", checks + 1L, " failed.", call. = FALSE)
    checks <<- checks + 1L
}
equal <- function(x, y, tol = 1e-8) {
    check(isTRUE(all.equal(unname(x), unname(y), tolerance = tol,
                           check.attributes = FALSE)))
}
errors <- function(expr, pattern) {
    err <- tryCatch({force(expr); NULL}, error = identity)
    check(inherits(err, "error") && grepl(pattern, conditionMessage(err), fixed = TRUE))
}
warnings <- function(expr, pattern) {
    seen <- character()
    ans <- withCallingHandlers(expr, warning = function(w) {
        seen <<- c(seen, conditionMessage(w))
        invokeRestart("muffleWarning")
    })
    check(any(grepl(pattern, seen, fixed = TRUE)))
    ans
}

# Known jump weights; linear-time implementation against a direct product.
equal(km_weights_function(c(1, 0, 1, 1), ratio_censoring = 1)$weights,
      c(0.25, 0, 0.375, 0.375))
equal(km_weights_function(1)$weights, 1)
equal(km_weights_function(0)$weights, 0)
set.seed(10)
for (n in c(2, 15, 80)) {
    d <- rbinom(n, 1, 0.35)
    equal(km_weights_function(d, 0.8, 0.2)$weights, reference_weights(d, 0.8, 0.2))
}
errors(km_weights_function(c(1, NA)), "delt")
errors(km_weights_function(c(1, 2)), "delt")

# Compare the diagonal-matrix transformation including a single event/column.
for (p in c(1, 3)) {
    X <- matrix(seq_len(6 * p), 6, p)
    for (d in list(c(1, 0, 1, 1, 0, 1), c(0, 0, 1, 0, 0, 0))) {
        w <- km_weights_function(d, ratio_censoring = 1)$weights
        y <- seq_len(sum(d))
        got <- km_transformation_function(X, y, w, d)
        ref <- reference_transform(X, y, w, d)
        equal(got$X_transformation, ref$x)
        equal(got$Y_transformation, ref$y)
        check(is.matrix(got$X_transformation))
    }
}
errors(km_transformation_function(1:3, 1:3, c(1, 0, 1), c(1, 0, 1)), "Y must have length")
errors(km_transformation_function(1:3, 1:2, c(1, 1, 1), c(1, 0, 1)), "zero for censored")
equal(data_seq(1:9, 2), c(1, 5, 9))
equal(fky_split(1:10, 1)$fky_list[[1]], 1:10)
equal(do.call(cbind, fky_split(1:10, 3)$fky_list),
      unclass(splines::bs(1:10, df = 3, degree = 2)))
errors(fky_split(rep(1, 10), 3), "distinct")

# Seeded full algorithm regression, using independent reference code.
# These are numerical smoke/regression checks, not FDR simulations.
set.seed(100)
X <- matrix(rnorm(180 * 6), 180, 6)
colnames(X) <- paste0("v", seq_len(ncol(X)))
latent <- 2 * X[, 1] - 1.5 * X[, 2] + X[, 3] + rnorm(180, sd = 0.5)
censor <- rnorm(180, mean = 4, sd = 2)
Y <- pmin(latent, censor)
d <- as.integer(latent <= censor)
for (h in c(1L, 3L)) {
    set.seed(90 + h)
    old_rng <- .Random.seed
    got <- MFSDA_SUR(X, Y, d, h = h, DS = 2, B = 8,
                     fdrlevel = c(0.1, 0.2))
    after <- .Random.seed
    .Random.seed <- old_rng
    ref <- reference_select(X, Y, d, h = h, DS = 2, B = 8, q = c(0.1, 0.2))
    equal(got$result, ref$result)
    equal(got$selection_rate, ref$rates)
    equal(got$split_selection, ref$votes)
    equal(got$statistics, ref$statistics, tol = 1e-6)
    check(identical(.Random.seed, after))
    check(all(got$diagnostics$status == "ok"))
    check(all(got$diagnostics$invalid_coefficients == 0))
    check(all(got$diagnostics$replaced_se == 0))
}

# Local seed restores RNG and yields stable selected results.
set.seed(88)
before <- .Random.seed
a <- MFSDA_SUR(X, Y, d, h = 1, DS = 1, B = 5, seed = 99)
check(identical(before, .Random.seed))
b <- MFSDA_SUR(X, Y, d, h = 1, DS = 1, B = 5, seed = 99)
check(identical(a$result, b$result))
check(identical(a$statistics, b$statistics))
check(identical(dim(a$result), c(6L, 1L)))
check(identical(rownames(a$result), colnames(X)))
check(identical(dim(a$split_selection), c(6L, 1L, 1L)))
check(identical(dim(a$thresholds), c(1L, 1L)))

# Main p=1 behavior intentionally preserves the <=1-candidate rule.
one <- MFSDA_SUR(X[, 1], Y, d, h = 1, DS = 1, B = 3, seed = 13)
check(identical(dim(one$result), c(1L, 1L)))
check(all(one$result == 0))
check(one$diagnostics$status == "at_most_one_candidate")
empty <- MFSDA_SUR(matrix(1, 180, 2), Y, d, h = 1, DS = 1, B = 3, seed = 13)
check(all(empty$result == 0))

# Small screening sample explicitly diagnosed, never silently fed to glmnet.
small <- warnings(AFT_WLS_lasso(X, Y, rep(1, 180), rep(1, 180), h = 1,
                                sample_index = 1:5), "Fewer than nine")
check(length(small$index_candidate_0) == 0)

# Refits handle one selected column and exact rank deficiency.
ord <- order(Y)
xx <- X[ord, , drop = FALSE]
yy <- Y[ord]
dd <- d[ord]
ww <- 180 * km_weights_function(dd, 0.9)$weights
S <- matrix(0L, 1, 6); S[1, 1] <- 1L
single <- AFT_WLS(xx, yy, ww, dd, 1, S, 1:150)$model.save_WLS
obj <- reference_transform(xx[1:150, 1, drop = FALSE], yy[1:150][dd[1:150] == 1], ww[1:150], dd[1:150])
equal(single[1, 1], stats::coef(stats::lm(obj$y ~ obj$x))[-1L])
check(all(is.na(single[-1, 1])))
rankx <- cbind(xx[, 1], xx[, 1])
rankfit <- AFT_WLS(rankx, yy, ww, dd, 1, matrix(1, 1, 2), 1:150)
check(is.na(rankfit$model.save_WLS[2, 1]))
se <- AFT_WLS_se(xx, yy, ww, dd, 1, S, sample_index = 1:150, B = 5, seed = 2)
check(se$valid_replicates[1, 1] == 5L)
check(is.finite(se$se_matrix[1, 1]))
rankse <- AFT_WLS_se(rankx, yy, ww, dd, 1, matrix(1, 1, 2),
                     sample_index = 1:150, B = 5, seed = 2)
check(is.na(rankse$se_matrix[2, 1]))
check(rankse$valid_replicates[2, 1] == 0L)

# Insufficient-event splits stay in the denominator and report their status.
sparse <- warnings(MFSDA_SUR(X[1:30, , drop = FALSE], Y[1:30],
    c(rep(1, 12), rep(0, 18)), h = 1, DS = 3, B = 3, seed = 5),
    "insufficient events")
check(any(sparse$diagnostics$status == "insufficient_events"))
skipped <- which(sparse$diagnostics$status == "insufficient_events")
check(all(sparse$split_selection[, skipped, , drop = FALSE] == 0L))
check(all(is.na(sparse$statistics[, skipped, drop = FALSE])))
equal(sparse$selection_rate[, 1],
      rowMeans(matrix(sparse$split_selection[, , 1], ncol(X), 3)))

# Heuristic aggregation and tie behavior.
combined <- MFSDA_SUR_combine(X, Y, d, h_value = 2, DS = 1, B = 5, seed = 40)
check(combined$h_opt == which.max(combined$selection_counts))
check(identical(combined$result, combined$fits[[combined$h_opt]]$result))
equal(combined$selection_counts, vapply(combined$fits, function(z) sum(z$result), numeric(1)))
zero <- MFSDA_SUR_combine(matrix(1, 180, 2), Y, d, h_value = 2, DS = 1, B = 3, seed = 40)
check(zero$h_opt == 1L)

# Threshold edge cases and invalid inputs.
threshold <- getFromNamespace(".mirror_threshold", "MFSDASUR")
check(is.infinite(threshold(c(-3, -2, -1), 0.1)))
check(is.infinite(threshold(rep(0, 3), 0.1)))
equal(threshold(c(-1, 2, 3), 0.1), 2)
errors(MFSDA_SUR(X, Y, rep(0, 180)), "observed event")
errors(MFSDA_SUR(X, Y[-1], d), "Y must have length")
errors(MFSDA_SUR(X, Y, d, h = 1.5), "h must")
errors(MFSDA_SUR(X, Y, d, fdrlevel = c(0.1, 1)), "fdrlevel")
errors(MFSDA_SUR(X, Y, d, DS = 0), "DS must")
errors(MFSDA_SUR(X, Y, d, B = 1), "B must")
errors(MFSDA_SUR(X, Y, d, seed = -1), "seed must")
errors(MFSDA_SUR(X, Y, d, ratio_SDA = 0.99), "split must")
bad <- X; bad[1, 1] <- NA
errors(MFSDA_SUR(bad, Y, d), "finite numeric")
errors(MFSDA_SUR(data.frame(a = factor(1:180)), Y, d), "numeric")
errors(AFT_WLS(xx, yy, ww, dd, 1, S, c(1, 1)), "distinct row")
errors(MFSDA_SUR(X, Y, c(rep(1, 13), rep(0, 167)), quantile_value = 0.1), "positive finite sum")

cat("Passed", checks, "regression and validation assertions.\n")
